#include <iostream>
#include <iomanip>
#include <sstream>
#include <vector>
#include <array>

class SimCache
{
    unsigned long int access_count; // nombre d'accès mémoire
    unsigned long int miss_count; // nombre de défauts de cache

    std::vector< std::vector<unsigned long int> > BC; // tags
    std::vector< std::vector<unsigned long int> > LRU; // timestamps d'accès mémoire

    int total_size, line_size, num_lines_per_set;
    int num_sets; // number of sets in cache: derived from total_size, line_size, num_lines_per_set

    int N; // vector/matrix dimension: used only in logResult
    bool log_access; // output detailed log of memory accesses to stderr

    int cache(unsigned long int address)
    {
        if (log_access)
            std::cerr << std::hex << "Access address=" << address;

        address = address / (unsigned long int)line_size; // get rid of offset

        unsigned long int tag = address / (unsigned long int)num_sets;
        int set = address % num_sets;

        if (log_access)
            std::cerr << std::hex << ", set=" << set << ", tag=" << tag << ':';

        for (int line = 0; line < num_lines_per_set; ++line)
            if (BC[set][line] == tag) // found in cache
            {
                LRU[set][line] = access_count;

                if (log_access)
                    std::cerr << " hit\n";

                return 0;
            }

        int lru_line = lru(set);

        if (log_access)
            std::cerr << std::hex << " miss, replacing line " << lru_line
                      << ", old tag " << BC[set][lru_line] << '\n';

        BC[set][lru_line] = tag;
        LRU[set][lru_line] = access_count;

        return 1;
    }

    /* Returns the index of least recently used line in the set. */
    int lru(int set)
    {
        unsigned long int min_timestamp = LRU[set][0];
        int lru_line = 0;

        for (int line = 1; line < num_lines_per_set; ++line)
            if (LRU[set][line] < min_timestamp)
            {
                min_timestamp = LRU[set][line];
                lru_line = line;
            }

        return lru_line;
    }

public:

    SimCache(bool log_access) : log_access(log_access) {}

    ~SimCache() {}

    /* acces cache pour l'adresse z */
    void access(unsigned long int address)
    {
        ++access_count;
        miss_count += cache(address);
    }

    /* RAZ des memoires etiquettes et LRU */
    void reset(int p_total_size, int p_line_size, int p_num_lines_per_set, int p_N)
    {
        total_size = p_total_size;
        line_size = p_line_size;
        num_lines_per_set = p_num_lines_per_set;
        num_sets = total_size / (line_size * num_lines_per_set);
        N = p_N;

        if (log_access)
            std::cerr << std::dec << "\n*** Resetting cache to: total_size=" << total_size
                      << " o, line_size=" << line_size
                      << " o, " << num_lines_per_set << "-way associative, "
                      << "num_sets=" << num_sets << "\n\n";

        BC.resize(num_sets);
        for (auto &e : BC) e.resize(num_lines_per_set);

        LRU.resize(num_sets);
        for (auto &e : LRU) e.resize(num_lines_per_set);

        access_count = 0L;
        miss_count = 0L;

        for (int set = 0; set < num_sets; ++set)
            for (int line = 0; line < num_lines_per_set; ++line)
            {
                LRU[set][line] = 0L;
                BC[set][line] = 0L;
            }
    }

    void logMessage(const char * const msg)
    {
        std::cout << msg;
    }

    void logHeaderRow(bool Ncube = false)
    {
        std::ostringstream tmp;

        tmp << std::left
            << std::setw(15) << "TOTAL_SIZE"
            << std::setw(15) << "LINE_SIZE"
            << std::setw(15) << "LINES_PER_SET"
            << std::setw(15) << "NUM_SETS"
            << std::setw(15) << "N"
            << std::setw(15) << "Miss rate";

        if (Ncube)
            tmp << std::setw(15) << "Miss/(N*N*N)";

        std::cout << tmp.str() << "\n\n";
    }

    void logResult(bool Ncube =false)
    {
        std::ostringstream tmp;

        tmp << std::left << std::setw(15) << total_size
            << std::setw(15) << line_size
            << std::setw(15) << num_lines_per_set
            << std::setw(15) << num_sets
            << std::setw(15) << N
            << std::setw(15) << (float)miss_count/(float)access_count;

        if (Ncube)
            tmp << std::setw(15) << (float)miss_count/(N*N*N);

        std::cout << tmp.str() << '\n';
    }
};

// ************************************************************************************************
// ************************************************************************************************
// ************************************************************************************************
void calc3(int N, SimCache &cache, double *x, double *y)
{
    double s = 0;

    for (int i = 0; i < N; ++i)
    {
        cache.access((unsigned long int) &x[i]);
        cache.access((unsigned long int) &y[i]);

        s = s + x[i]*y[i];
    }
}

void run3(int N, bool detailed_log,
          const std::array<int, 3> &total_size_list,
          const std::array<int, 3> &line_size_list,
          const std::array<int, 3> &num_lines_per_set_list)
{
    SimCache cache(detailed_log);

    // Memory allocation
    double *raw = new double[N + N]; // contiguous memory for x[N], y[N]

    double *x = raw;
    double *y = raw + N;

    // init x, y
    for (int i = 0; i < N; ++i)
    {
        x[i] = i + N - 1;
        y[i] = i - N + 1;
    }

    // write log file header
    std::cout << "exo 3 : PRODUIT SCALAIRE\n\n"
              << "&x[0] = " << (void *)(&x[0]) << '\n'
              << "&y[0] = " << (void *)(&y[0]) << '\n'
              << "sizeof(double) = " << sizeof(double) << "\n\n";
    cache.logHeaderRow();

    for (auto total_size : total_size_list)
        for (auto line_size : line_size_list)
            for (auto num_lines_per_set : num_lines_per_set_list)
            {
                // init cache
                cache.reset(total_size, line_size, num_lines_per_set, N);

                // run calculation
                calc3(N, cache, x, y);

                // write result
                cache.logResult();
            }

    delete [] raw;
}


int main()
{
    int N = 64;
    bool detailed_log = false;

    // different cache sizes to simulate
    std::array<int, 3> total_size_list {4096, 8192, 16384};
    // different line sizes to simulate
    std::array<int, 3> line_size_list {16, 32, 64};
    // different numbers of lines per set to simulate
    std::array<int, 3> num_lines_per_set_list {1, 2, 4};

    run3(N, detailed_log, total_size_list, line_size_list, num_lines_per_set_list);
}

